//Autor: Ashley Leon Espinoza
//Fecha: 25/02/2025


package granja_examen;

public class Cartilla {

		private Animal animal;
		private int anno_nacimiento;
		private String nombre_vet;
		
		public Cartilla(Animal animal, int anno_nacimiento, String nombre_vet) {
			this.animal=animal;
			this.anno_nacimiento = anno_nacimiento;
			this.nombre_vet = nombre_vet;
		}

		
		public Animal getAnimal() {
			return animal;
		}

		public void setAnimal(Animal animal) {
			this.animal = animal;
		}

		public int getAnno_nacimiento() {
			return anno_nacimiento;
		}

		public void setAnno_nacimiento(int anno_nacimiento) {
			this.anno_nacimiento = anno_nacimiento;
		}



		public String getNombre_vet() {
			return nombre_vet;
		}

		public void setNombre_vet(String nombre_vet) {
			this.nombre_vet = nombre_vet;
		} 
		
		public String toString() {
			String s="";
			s+=("Mascota: "+ animal.toString());
			s+=("Anno de nacimiento: "+anno_nacimiento+"\n");
			s+=("Veterinario: "+nombre_vet+"\n");
			
			return s;
		}
}
