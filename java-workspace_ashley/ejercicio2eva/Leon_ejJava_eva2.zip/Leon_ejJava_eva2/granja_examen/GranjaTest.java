//Autor: Ashley Leon Espinoza
//Fecha: 25/02/2025


package granja_examen;

import java.util.ArrayList;

public class GranjaTest {

	public static void main(String[] args) {
		
		Animal a1 = new Perro ("Cody", 4, "Pomerania", "Mixto");
				
		Animal a2 = new Perro ("Zac", 1, "Pomerania", "Mixto");
		
		Animal a3 = new Perro ("Claudia", 2, "Pitbull", "Raza Pura");

		Animal a4 = new Gato ("Whiskers", 8, "Marron", "America");
		
		Animal a5 = new Gato ("Isabel", 5, "Blanco", "Islandia");
		
		ArrayList <Animal> Granja = new ArrayList<Animal>();
		
		Granja.add(a1);
		Granja.add(a2);
		Granja.add(a3);
		Granja.add(a4);
		Granja.add(a5);
		
		System.out.println(a1.toString());
		System.out.println(a2.toString());
		System.out.println(a3.toString());
		System.out.println(a4.toString());
		System.out.println(a5.toString());
		
		
		((Perro)a1).vacunar();
		((Perro)a2).vacunar();
		((Perro)a3).vacunar();
		((Gato)a4).vacunar();
		((Gato)a5).vacunar();
		
		((Perro)a3).enfermar();
		
		for (Animal a: Granja) {
			if (a instanceof Perro) {
				System.out.println((a.getNombre()));
				System.out.println(((Perro)a).comer());
				System.out.println(((Perro)a).hacerSonido());
				System.out.println(((Perro)a).moverse());
				System.out.println("");
			}
			
			if (a instanceof Gato) {
				System.out.println((a.getNombre()));
				System.out.println(((Gato)a).comer());
				System.out.println(((Gato)a).hacerSonido());
				System.out.println(((Gato)a).moverse());
				System.out.println("");
			}
		}
	
		System.out.println(a1.toString());
		System.out.println(a2.toString());
		System.out.println(a3.toString());
		System.out.println(a4.toString());
		System.out.println(a5.toString());
		System.out.println("Hay un total de "+Animal.getTotalAnimales());
	}

}
