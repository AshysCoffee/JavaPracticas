//Autor: Ashley Leon Espinoza
//Fecha: 25/02/2025


package granja_examen;

public class Gato extends Animal {

	private String color_pelo, pais_origen;
	private int enfermedades=0;
	private int vacunas=0;

	public Gato(String nombre, int edad, String color_pelo, String pais_origen) {
		super(nombre, edad);
		this.color_pelo = color_pelo;
		this.pais_origen = pais_origen;
	}

	public String getColor_pelo() {
		return color_pelo;
	}

	public void setColor_pelo(String color_pelo) {
		this.color_pelo = color_pelo;
	}

	public String getPais_origen() {
		return pais_origen;
	}

	public void setPais_origen(String pais_origen) {
		this.pais_origen = pais_origen;
	}
	
	
	public int getEnfermedades() {
		return enfermedades;
	}

	public void setEnfermedades(int enfermedades) {
		this.enfermedades = enfermedades;
	}

	public int getVacunas() {
		return vacunas;
	}

	public void setVacunas(int vacunas) {
		this.vacunas = vacunas;
	}

	public String hacerSonido() {
		return "Maúlla y dice miau, miau";
	}
	
	public String comer() {
		return "Come pescado";
	}
	
	public String moverse() {
		return "Salta de un mueble a otro";
	}
	
	public int enfermar() {
		enfermedades++;
		return enfermedades;
	}	
	
	public int vacunar() {
		vacunas++;
		return vacunas;
	}

	public String toString () {
		String s="";
		s+=(super.toString());
		s+=("Color de pelaje: "+color_pelo+"\n");
		s+=("País de origen: "+pais_origen+"\n");
		s+=("Vacunas: "+getVacunas()+"\n");
		s+=("Enfermedades: "+getEnfermedades()+"\n");
		s+=("-------------------");
		return s;
	}
	
	
	
}
