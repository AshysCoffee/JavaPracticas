//Autor: Ashley Leon Espinoza
//Fecha: 25/02/2025

package granja_examen;

public class Animal {
	
	//Creamos los dos atributos comunes entre todas las clases
	private String nombre;
	private int edad;
	
	//Este atributo estatico nos servira como contador de animales
	private static int totalAnimales=0;

	
	//CONSTRUCTOR
	public Animal(String nombre, int edad) {
		super();
		this.nombre = nombre;
		this.edad = edad;
		totalAnimales++;
		
	}
	
	//GETTERS - Para obtener la información del atributo
	//SETTERS - Para cambiar los atributos mediante parametros externos
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getEdad() {
		return edad;
	}
	
	//En este set se pone la condición de que la edad no puede ser menor a 0 
	public void setEdad(int edad) {
		if (edad>0) {
		this.edad = edad;
		}else{
		this.edad = 0;
		}
	}
	
	

	//Nos devolvera el total del contador
	public static int getTotalAnimales(){
		return totalAnimales;
	}
	

	//METODOS comunes que tendran las clases hijas, vacios para poder ser definidos en cada clase de forma que no haya conflictos
	public String hacerSonido() {
		return "";
	}
	
	public String comer() {
		return "";
	}
	
	public String moverse() {
		return "";
	}
	


	
	//TO STRING
	public String toString() {
		String s="";
		s+=("Nombre: "+nombre+"\n");
		s+=("Edad: "+edad+"\n");
		return s;
	}

}
