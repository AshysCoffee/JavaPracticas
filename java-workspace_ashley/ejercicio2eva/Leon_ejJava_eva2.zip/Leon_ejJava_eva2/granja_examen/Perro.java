//Autor: Ashley Leon Espinoza
//Fecha: 25/02/2025


package granja_examen;

public class Perro extends Animal{
	
	private String raza, pedrigri;
	private int enfermedades=0;
	private int vacunas=0;

	public Perro(String nombre, int edad, String raza, String pedrigri) {
		super(nombre, edad);
		this.raza = raza;
		this.pedrigri = pedrigri;
	}

	public String getRaza() {
		return raza;
	}

	public void setRaza(String raza) {
		this.raza = raza;
	}

	public String getPedrigri() {
		return pedrigri;
	}

	public void setPedrigri(String pedrigri) {
		this.pedrigri = pedrigri;
	}
	
	public int getEnfermedades() {
		return enfermedades;
	}

	public void setEnfermedades(int enfermedades) {
		this.enfermedades = enfermedades;
	}

	public int getVacunas() {
		return vacunas;
	}

	public void setVacunas(int vacunas) {
		this.vacunas = vacunas;
	}

	//SOBREESCRIBIMOS LOS METODOS DE LA SUPERCLASE ANIMAL
	public String hacerSonido() {
		return "Ladra y dice guau, guau";
	}
	
	public String comer() {
		return "Come croquetas";
	}
	
	public String moverse() {
		return "Corre felizmente";
	}
	
	public int enfermar() {
		enfermedades++;
		return enfermedades;
	}	
	
	public int vacunar() {
		vacunas++;
		return vacunas;
	}

	
	public String toString () {
		String s="";
		s+=(super.toString());
		s+=("Raza: "+raza+"\n");
		s+=("Pedrigri: "+pedrigri+"\n");
		s+=("Vacunas: "+getVacunas()+"\n");
		s+=("Enfermedades: "+getEnfermedades()+"\n");
		s+=("-------------------");
		return s;
	}

}
