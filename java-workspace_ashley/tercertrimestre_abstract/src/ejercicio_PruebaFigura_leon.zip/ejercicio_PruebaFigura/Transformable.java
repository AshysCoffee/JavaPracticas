package ejercicio_PruebaFigura;

public interface Transformable {

	public void Escalar (double factor);
	
}
