package ejercicio_PruebaFigura;

public interface Colorable {

	public void cambiarColor(Colores color);
	
	public Colores IndicaColor();
	
}
