package ejercicio_PruebaFigura;

public enum Colores { ROJO, NARANJA, AMARILLO, VERDE, AZUL, MORADO }
